package com.aegon.survey.demo.entity;

public interface Entity {
	Long getId();

	void setId(final Long id);
}
