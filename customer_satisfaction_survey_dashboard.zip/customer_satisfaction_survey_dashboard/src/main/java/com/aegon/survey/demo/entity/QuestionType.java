package com.aegon.survey.demo.entity;

public enum QuestionType {

	RADIO,
	INPUT,
	SELECT,
	CHECK

}
